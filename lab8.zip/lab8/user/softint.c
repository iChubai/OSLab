#include <stdio.h>
#include <ulib.h>

int
main(void) {
    // asm volatile("int $14");
    exit(0);
    panic("FAIL: T.T\n");
}

